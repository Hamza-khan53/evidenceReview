const API_BASE = window.EVIDENCE_REVIEW_API || "";

const dropzone = document.getElementById("dropzone");
const fileInput = document.getElementById("fileInput");
const thumbsEl = document.getElementById("thumbs");
const submitBtn = document.getElementById("submitBtn");
const formNote = document.getElementById("formNote");
const serverStatus = document.getElementById("serverStatus");

const ledgerEmpty = document.getElementById("ledgerEmpty");
const ledgerResult = document.getElementById("ledgerResult");
const ledgerError = document.getElementById("ledgerError");

let selectedFiles = [];

// ---------- file handling ----------
function renderThumbs() {
  thumbsEl.innerHTML = "";
  selectedFiles.forEach((file) => {
    const url = URL.createObjectURL(file);
    const div = document.createElement("div");
    div.className = "thumb";
    const img = document.createElement("img");
    img.src = url;
    img.alt = file.name;
    const label = document.createElement("span");
    label.className = "thumb__id";
    label.textContent = file.name;
    div.append(img, label);
    thumbsEl.appendChild(div);
  });
}

dropzone.addEventListener("click", () => fileInput.click());
dropzone.addEventListener("dragover", (e) => {
  e.preventDefault();
  dropzone.classList.add("dragover");
});
dropzone.addEventListener("dragleave", () => dropzone.classList.remove("dragover"));
dropzone.addEventListener("drop", (e) => {
  e.preventDefault();
  dropzone.classList.remove("dragover");
  addFiles(e.dataTransfer.files);
});
fileInput.addEventListener("change", (e) => addFiles(e.target.files));

function addFiles(fileList) {
  for (const f of fileList) {
    if (f.type.startsWith("image/")) selectedFiles.push(f);
  }
  renderThumbs();
}

// ---------- server health ----------
async function checkHealth() {
  try {
    const res = await fetch(`${API_BASE}/api/health`);
    const data = await res.json();
    if (data.model_configured) {
      serverStatus.textContent = "server online · model configured";
      serverStatus.className = "topbar__status ok";
    } else {
      serverStatus.textContent = "server online · ANTHROPIC_API_KEY missing";
      serverStatus.className = "topbar__status bad";
    }
  } catch (e) {
    serverStatus.textContent = "backend not reachable";
    serverStatus.className = "topbar__status bad";
  }
}
checkHealth();

// ---------- submit ----------
submitBtn.addEventListener("click", async () => {
  const claimObject = document.getElementById("claimObject").value;
  const userClaim = document.getElementById("userClaim").value.trim();

  if (!userClaim) {
    formNote.textContent = "Add a claim description before submitting.";
    return;
  }
  if (selectedFiles.length === 0) {
    formNote.textContent = "Attach at least one evidence photo before submitting.";
    return;
  }

  formNote.textContent = "";
  submitBtn.disabled = true;
  submitBtn.querySelector("span").textContent = "Reviewing…";

  const form = new FormData();
  form.append("claim_object", claimObject);
  form.append("user_claim", userClaim);
  selectedFiles.forEach((f) => form.append("files", f));

  try {
    const res = await fetch(`${API_BASE}/api/claims`, { method: "POST", body: form });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || data.detail || "Request failed");
    renderVerdict(data);
    refreshBadge();
  } catch (err) {
    showError(err.message || String(err));
  } finally {
    submitBtn.disabled = false;
    submitBtn.querySelector("span").textContent = "Submit for review";
  }
});

function showError(message) {
  ledgerEmpty.hidden = true;
  ledgerResult.hidden = true;
  ledgerError.hidden = false;
  ledgerError.textContent = `Review failed: ${message}`;
}

function stampClassFor(status) {
  if (status === "supported") return "stamp--supported";
  if (status === "contradicted") return "stamp--contradicted";
  return "stamp--insufficient";
}

const REVIEW_LABELS = {
  auto: "Auto-decided",
  pending: "Awaiting review",
  approved: "Approved",
  rejected: "Rejected",
  needs_more_info: "More info requested",
};

let currentClaimId = null;

function confidenceClass(c) {
  if (c >= 0.8) return "";
  if (c >= 0.6) return "mid";
  return "low";
}

function renderVerdict(data) {
  ledgerEmpty.hidden = true;
  ledgerError.hidden = true;
  ledgerResult.hidden = false;
  currentClaimId = data.id ?? null;

  const stamp = document.getElementById("stampBadge");
  stamp.textContent = data.claim_status.replace(/_/g, " ");
  stamp.className = `stamp ${stampClassFor(data.claim_status)}`;

  const conf = Number(data.confidence ?? 0);
  document.getElementById("rConfidence").textContent = `${Math.round(conf * 100)}%`;
  const fill = document.getElementById("rConfidenceFill");
  fill.style.width = `${Math.round(conf * 100)}%`;
  fill.className = `confidence__fill ${confidenceClass(conf)}`;

  document.getElementById("rIssueType").textContent = data.issue_type;
  document.getElementById("rObjectPart").textContent = data.object_part;
  document.getElementById("rSeverity").textContent = data.severity;
  document.getElementById("rEvidenceMet").textContent = data.evidence_standard_met ? "true" : "false";
  document.getElementById("rSupportingIds").textContent = data.supporting_image_ids || "none";
  document.getElementById("rRiskFlags").textContent = data.risk_flags || "none";
  document.getElementById("rEvidenceReason").textContent = data.evidence_standard_met_reason || "—";
  document.getElementById("rJustification").textContent = data.claim_status_justification || "—";
  document.getElementById("rLatency").textContent =
    `model latency: ${data.latency_seconds ?? "—"}s · images reviewed: ${(data.image_ids || []).length}`;

  renderReviewState(data.review_status, data.review_note);
}

function renderReviewState(status, note) {
  const banner = document.getElementById("reviewBanner");
  const panel = document.getElementById("reviewPanel");
  banner.className = "review-banner";
  banner.hidden = true;
  panel.hidden = true;
  if (!status || status === "auto" || currentClaimId == null) return;

  banner.hidden = false;
  if (status === "pending") {
    banner.textContent = "Flagged for human review: the model was uncertain or marked this case as borderline. Record a decision below.";
    panel.hidden = false;
    document.getElementById("reviewNote").value = "";
  } else {
    banner.classList.add(status === "rejected" ? "bad" : "done");
    banner.textContent = `Reviewer decision: ${REVIEW_LABELS[status] || status}.` + (note ? ` Note: ${note}` : "");
  }
}

document.querySelectorAll("#reviewPanel [data-decision]").forEach((btn) => {
  btn.addEventListener("click", async () => {
    if (currentClaimId == null) return;
    const buttons = document.querySelectorAll("#reviewPanel [data-decision]");
    buttons.forEach((b) => (b.disabled = true));
    try {
      const res = await fetch(`${API_BASE}/api/claims/${currentClaimId}/review`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          decision: btn.dataset.decision,
          note: document.getElementById("reviewNote").value,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.detail || "Could not save decision");
      renderReviewState(data.review_status, data.review_note);
      loadHistory();
    } catch (err) {
      alert(err.message || String(err));
    } finally {
      buttons.forEach((b) => (b.disabled = false));
    }
  });
});

// ---------- view switching ----------
const viewDesk = document.getElementById("viewDesk");
const viewHistory = document.getElementById("viewHistory");

function showView(name) {
  viewDesk.hidden = name !== "desk";
  viewHistory.hidden = name !== "history";
  document.querySelectorAll(".nav__btn").forEach((b) =>
    b.classList.toggle("is-active", b.dataset.view === name)
  );
  if (name === "history") loadHistory();
}
document.querySelectorAll(".nav__btn").forEach((b) =>
  b.addEventListener("click", () => showView(b.dataset.view))
);

// ---------- case history ----------
const casesBody = document.getElementById("casesBody");
const historyEmpty = document.getElementById("historyEmpty");
const filterStatus = document.getElementById("filterStatus");
const filterReview = document.getElementById("filterReview");
const pendingBadge = document.getElementById("pendingBadge");

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function pillFor(status) {
  const label = status.replace(/_/g, " ");
  return el("span", `pill ${status === "supported" ? "pill--supported" : status === "contradicted" ? "pill--contradicted" : "pill--insufficient"}`, label);
}

function renderStats(stats) {
  const box = document.getElementById("stats");
  box.replaceChildren();
  const items = [
    [stats.total, "Total cases"],
    [stats.pending_review, "Awaiting review"],
    [stats.by_status.supported || 0, "Supported"],
    [stats.by_status.contradicted || 0, "Contradicted"],
    [stats.avg_confidence == null ? "—" : `${Math.round(stats.avg_confidence * 100)}%`, "Avg confidence"],
  ];
  for (const [n, label] of items) {
    const card = el("div", "stat");
    card.append(el("div", "stat__n", String(n)), el("div", "stat__l", label));
    box.appendChild(card);
  }
  pendingBadge.hidden = !stats.pending_review;
  pendingBadge.textContent = stats.pending_review;
}

async function loadHistory() {
  const params = new URLSearchParams();
  if (filterStatus.value) params.set("claim_status", filterStatus.value);
  if (filterReview.value) params.set("review_status", filterReview.value);
  try {
    const [listRes, statsRes] = await Promise.all([
      fetch(`${API_BASE}/api/claims?${params}`),
      fetch(`${API_BASE}/api/stats`),
    ]);
    const { claims } = await listRes.json();
    renderStats(await statsRes.json());

    casesBody.replaceChildren();
    historyEmpty.hidden = claims.length > 0;
    for (const c of claims) {
      const tr = document.createElement("tr");
      tr.title = "Open this case";
      const reviewCell = el("td");
      reviewCell.appendChild(
        c.review_status === "pending"
          ? el("span", "pill pill--pending", REVIEW_LABELS.pending)
          : el("span", "", REVIEW_LABELS[c.review_status] || c.review_status)
      );
      const verdictCell = el("td");
      verdictCell.appendChild(pillFor(c.claim_status));
      tr.append(
        el("td", "", String(c.id)),
        el("td", "", new Date(c.created_at).toLocaleString()),
        el("td", "", c.claim_object),
        el("td", "cases__claim", c.user_claim),
        verdictCell,
        el("td", "", `${Math.round(c.confidence * 100)}%`),
        reviewCell
      );
      tr.addEventListener("click", () => openCase(c.id));
      casesBody.appendChild(tr);
    }
  } catch (e) {
    casesBody.replaceChildren();
    historyEmpty.hidden = false;
    historyEmpty.textContent = "Could not load case history.";
  }
}

async function openCase(id) {
  try {
    const res = await fetch(`${API_BASE}/api/claims/${id}`);
    const c = await res.json();
    if (!res.ok) throw new Error(c.detail || "Not found");
    showView("desk");
    renderVerdict({ ...c.result, id: c.id, review_status: c.review_status, review_note: c.review_note });
  } catch (err) {
    showView("desk");
    showError(err.message || String(err));
  }
}

filterStatus.addEventListener("change", loadHistory);
filterReview.addEventListener("change", loadHistory);

async function refreshBadge() {
  try {
    renderStats(await (await fetch(`${API_BASE}/api/stats`)).json());
  } catch (e) { /* non-critical */ }
}
refreshBadge();
