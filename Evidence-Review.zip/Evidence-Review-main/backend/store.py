"""
SQLite persistence for submitted claims and their review state.

Uses only the standard library. On hosts with an ephemeral filesystem (e.g.
Render's free tier) the database resets on redeploy; point EVIDENCE_DB at a
persistent disk or swap this module for Postgres to keep history long-term.
"""
import json
import os
import sqlite3
import threading
from datetime import datetime, timezone

DB_PATH = os.environ.get(
    "EVIDENCE_DB", os.path.join(os.path.dirname(__file__), "claims.db")
)
_lock = threading.Lock()

_SCHEMA = """
CREATE TABLE IF NOT EXISTS claims (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at    TEXT NOT NULL,
    claim_object  TEXT NOT NULL,
    user_claim    TEXT NOT NULL,
    claim_status  TEXT NOT NULL,
    confidence    REAL NOT NULL,
    severity      TEXT,
    issue_type    TEXT,
    review_status TEXT NOT NULL DEFAULT 'auto',
    review_note   TEXT,
    reviewed_at   TEXT,
    result_json   TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_claims_created ON claims(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_claims_review ON claims(review_status);
"""


def _connect():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with _lock, _connect() as conn:
        conn.executescript(_SCHEMA)


def _now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _row_to_dict(row, include_result=False):
    d = {k: row[k] for k in row.keys() if k != "result_json"}
    if include_result:
        d["result"] = json.loads(row["result_json"])
    return d


def save_claim(result: dict, needs_review: bool) -> int:
    with _lock, _connect() as conn:
        cur = conn.execute(
            """INSERT INTO claims (created_at, claim_object, user_claim, claim_status,
                                   confidence, severity, issue_type, review_status, result_json)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                _now(),
                result["claim_object"],
                result["user_claim"],
                result["claim_status"],
                result.get("confidence", 0.0),
                result.get("severity"),
                result.get("issue_type"),
                "pending" if needs_review else "auto",
                json.dumps(result),
            ),
        )
        return cur.lastrowid


def list_claims(claim_status=None, review_status=None, limit=100):
    q, args = "SELECT * FROM claims WHERE 1=1", []
    if claim_status:
        q += " AND claim_status = ?"
        args.append(claim_status)
    if review_status:
        q += " AND review_status = ?"
        args.append(review_status)
    q += " ORDER BY id DESC LIMIT ?"
    args.append(max(1, min(int(limit), 500)))
    with _lock, _connect() as conn:
        return [_row_to_dict(r) for r in conn.execute(q, args).fetchall()]


def get_claim(claim_id: int):
    with _lock, _connect() as conn:
        row = conn.execute("SELECT * FROM claims WHERE id = ?", (claim_id,)).fetchone()
    return _row_to_dict(row, include_result=True) if row else None


def set_review(claim_id: int, decision: str, note: str):
    with _lock, _connect() as conn:
        cur = conn.execute(
            "UPDATE claims SET review_status = ?, review_note = ?, reviewed_at = ? WHERE id = ?",
            (decision, note, _now(), claim_id),
        )
        return cur.rowcount > 0


def stats():
    with _lock, _connect() as conn:
        total = conn.execute("SELECT COUNT(*) FROM claims").fetchone()[0]
        by_status = {
            r["claim_status"]: r["n"]
            for r in conn.execute(
                "SELECT claim_status, COUNT(*) AS n FROM claims GROUP BY claim_status"
            )
        }
        pending = conn.execute(
            "SELECT COUNT(*) FROM claims WHERE review_status = 'pending'"
        ).fetchone()[0]
        avg_conf = conn.execute("SELECT AVG(confidence) FROM claims").fetchone()[0]
    return {
        "total": total,
        "by_status": by_status,
        "pending_review": pending,
        "avg_confidence": round(avg_conf, 3) if avg_conf is not None else None,
    }
