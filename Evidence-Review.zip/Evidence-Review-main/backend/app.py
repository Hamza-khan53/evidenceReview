"""
FastAPI backend for the Evidence Review demo frontend.

Wraps the exact same adjudication logic used by the batch pipeline
(code/claim_processor.py from the hackathon submission) behind a single
HTTP endpoint that accepts uploaded images + a claim description and
returns the structured verdict as JSON.

Run:
    cd backend
    pip install -r requirements.txt
    export ANTHROPIC_API_KEY=sk-...
    uvicorn app:app --reload --port 8000

The frontend (frontend/index.html) expects this running at
http://localhost:8000.
"""
import json
import os
import sys
import tempfile
import time
from typing import List

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

# Reuse the exact pipeline logic from the hackathon submission's code/ directory.
# Point this at wherever you put schema.py / prompts.py / claim_processor.py.
PIPELINE_CODE_DIR = os.environ.get(
    "PIPELINE_CODE_DIR", os.path.join(os.path.dirname(__file__), "..", "pipeline")
)
sys.path.insert(0, PIPELINE_CODE_DIR)

import schema  # noqa: E402
import store  # noqa: E402
from prompts import SYSTEM_PROMPT, build_user_prompt  # noqa: E402

app = FastAPI(title="Evidence Review API")
store.init_db()

MAX_FILES = 8
MAX_FILE_BYTES = 8 * 1024 * 1024  # 8 MB per image
ALLOWED_IMAGE_TYPES = {"image/jpeg", "image/png", "image/webp", "image/gif"}

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # demo only -- lock this down for anything real
    allow_methods=["*"],
    allow_headers=["*"],
)


def get_client():
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        return None
    import anthropic
    return anthropic.Anthropic(api_key=api_key)


def _extract_json(text: str) -> dict:
    text = text.strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.lower().startswith("json"):
            text = text[4:]
    start, end = text.find("{"), text.rfind("}")
    if start == -1 or end == -1:
        raise ValueError(f"No JSON object found in model output: {text[:200]!r}")
    return json.loads(text[start:end + 1])


def adjudicate(claim_object: str, user_claim: str, images: List[dict]) -> dict:
    """
    images: list of {"id": str, "media_type": str, "data_b64": str}
    Mirrors claim_processor.process_claim but takes in-memory uploads
    instead of dataset CSV rows.
    """
    if not images:
        return {
            "evidence_standard_met": False,
            "evidence_standard_met_reason": "No images were uploaded with this claim.",
            "risk_flags": "none",
            "issue_type": "unknown",
            "object_part": "unknown",
            "claim_status": "not_enough_information",
            "claim_status_justification": "No images were uploaded with this claim.",
            "supporting_image_ids": "none",
            "valid_image": False,
            "severity": "unknown",
            "confidence": 0.0,
        }

    client = get_client()
    if client is None:
        return {
            "evidence_standard_met": False,
            "evidence_standard_met_reason": "ANTHROPIC_API_KEY is not configured on the server.",
            "risk_flags": "none",
            "issue_type": "unknown",
            "object_part": "unknown",
            "claim_status": "not_enough_information",
            "claim_status_justification": "Server is not configured to run vision adjudication.",
            "supporting_image_ids": "none",
            "valid_image": False,
            "severity": "unknown",
            "confidence": 0.0,
        }

    content = []
    ids = []
    for im in images:
        content.append({"type": "text", "text": f"Image ID: {im['id']}"})
        content.append({
            "type": "image",
            "source": {"type": "base64", "media_type": im["media_type"], "data": im["data_b64"]},
        })
        ids.append(im["id"])

    user_text = build_user_prompt(
        claim_object=claim_object,
        user_claim=user_claim,
        requirement=None,  # wire in evidence_requirements.csv lookup here if available
        history_text="unknown (no user_history provided in this demo)",
        image_ids_in_order=ids,
        missing_image_paths=[],
    )
    content.append({"type": "text", "text": user_text})

    resp = client.messages.create(
        model=os.environ.get("CLAIM_REVIEW_MODEL", "claude-sonnet-4-6"),
        max_tokens=1000,
        system=SYSTEM_PROMPT,
        messages=[{"role": "user", "content": content}],
    )
    text = "".join(b.text for b in resp.content if getattr(b, "type", "") == "text")
    parsed = _extract_json(text)

    return {
        "evidence_standard_met": bool(parsed.get("evidence_standard_met", False)),
        "evidence_standard_met_reason": str(parsed.get("evidence_standard_met_reason", "")),
        "risk_flags": schema.sanitize_risk_flags(parsed.get("risk_flags", [])),
        "issue_type": schema.closest_issue_type(str(parsed.get("issue_type", "unknown"))),
        "object_part": schema.closest_object_part(claim_object, str(parsed.get("object_part", "unknown"))),
        "claim_status": schema.closest_claim_status(str(parsed.get("claim_status", "not_enough_information"))),
        "claim_status_justification": str(parsed.get("claim_status_justification", "")),
        "supporting_image_ids": ";".join(
            [s for s in parsed.get("supporting_image_ids", []) if s in ids]
        ) or "none",
        "valid_image": bool(parsed.get("valid_image", False)),
        "severity": schema.closest_severity(str(parsed.get("severity", "unknown"))),
        "confidence": schema.clamp_confidence(parsed.get("confidence")),
    }


@app.get("/api/health")
def health():
    return {"status": "ok", "model_configured": get_client() is not None}


def _apply_review_gate(result: dict) -> bool:
    """
    Route low-confidence or ambiguous verdicts to a human review queue.
    Adds the manual_review_required flag and returns True when review is needed.
    """
    flags = [f for f in result["risk_flags"].split(";") if f and f != "none"]
    low_conf = (
        result["claim_status"] != "not_enough_information"
        and result.get("confidence", 0.0) < schema.MANUAL_REVIEW_THRESHOLD
    )
    needs_review = low_conf or "manual_review_required" in flags
    if needs_review and "manual_review_required" not in flags:
        flags.append("manual_review_required")
    result["risk_flags"] = ";".join(flags) if flags else "none"
    result["needs_review"] = needs_review
    return needs_review


@app.post("/api/claims")
async def submit_claim(
    claim_object: str = Form(...),
    user_claim: str = Form(...),
    files: List[UploadFile] = File(default=[]),
):
    import base64

    if claim_object not in schema.CLAIM_OBJECTS:
        raise HTTPException(400, f"claim_object must be one of {sorted(schema.CLAIM_OBJECTS)}")
    user_claim = user_claim.strip()
    if not user_claim or len(user_claim) > 4000:
        raise HTTPException(400, "user_claim must be between 1 and 4000 characters")
    if len(files) > MAX_FILES:
        raise HTTPException(400, f"At most {MAX_FILES} images per claim")

    images = []
    for f in files:
        if (f.content_type or "") not in ALLOWED_IMAGE_TYPES:
            raise HTTPException(400, f"Unsupported file type: {f.content_type!r}")
        raw = await f.read()
        if len(raw) > MAX_FILE_BYTES:
            raise HTTPException(400, f"{f.filename} is larger than {MAX_FILE_BYTES // (1024 * 1024)} MB")
        img_id = os.path.splitext(f.filename or f"image_{len(images)+1}")[0]
        images.append({
            "id": img_id,
            "media_type": f.content_type,
            "data_b64": base64.standard_b64encode(raw).decode("utf-8"),
        })

    started = time.time()
    try:
        result = adjudicate(claim_object, user_claim, images)
    except Exception as e:  # noqa: BLE001
        return JSONResponse(status_code=500, content={"error": str(e)})

    result["latency_seconds"] = round(time.time() - started, 2)
    result["claim_object"] = claim_object
    result["user_claim"] = user_claim
    result["image_ids"] = [im["id"] for im in images]

    needs_review = _apply_review_gate(result)
    result["id"] = store.save_claim(result, needs_review)
    result["review_status"] = "pending" if needs_review else "auto"
    return result


# ---------------------------------------------------------------------------
# Case history + review queue
# ---------------------------------------------------------------------------
@app.get("/api/claims")
def list_claims(claim_status: str | None = None, review_status: str | None = None, limit: int = 100):
    return {"claims": store.list_claims(claim_status, review_status, limit)}


@app.get("/api/claims/{claim_id}")
def get_claim(claim_id: int):
    claim = store.get_claim(claim_id)
    if not claim:
        raise HTTPException(404, "Claim not found")
    return claim


class ReviewDecision(BaseModel):
    decision: str
    note: str = ""


@app.post("/api/claims/{claim_id}/review")
def review_claim(claim_id: int, body: ReviewDecision):
    if body.decision not in schema.REVIEW_DECISIONS:
        raise HTTPException(400, f"decision must be one of {sorted(schema.REVIEW_DECISIONS)}")
    if not store.set_review(claim_id, body.decision, body.note.strip()[:1000]):
        raise HTTPException(404, "Claim not found")
    return store.get_claim(claim_id)


@app.get("/api/stats")
def get_stats():
    return store.stats()


# ---------------------------------------------------------------------------
# Serve the frontend (frontend/index.html, styles.css, app.js) from this same
# FastAPI app so a single deploy (e.g. one Render web service) serves both
# the UI and the API -- no separate static host, no cross-origin requests.
# Must be mounted LAST, after all /api/* routes above.
# ---------------------------------------------------------------------------
FRONTEND_DIR = os.environ.get(
    "FRONTEND_DIR", os.path.join(os.path.dirname(__file__), "..", "frontend")
)
FRONTEND_DIR = os.path.abspath(FRONTEND_DIR)
print(f"[startup] FRONTEND_DIR resolved to: {FRONTEND_DIR}", flush=True)
print(f"[startup] FRONTEND_DIR exists: {os.path.isdir(FRONTEND_DIR)}", flush=True)

if os.path.isdir(FRONTEND_DIR):
    print(f"[startup] mounting static frontend from {FRONTEND_DIR}", flush=True)
    app.mount("/", StaticFiles(directory=FRONTEND_DIR, html=True), name="frontend")
else:
    print(f"[startup] WARNING: frontend dir not found, '/' will 404. Check the deploy layout.", flush=True)

    @app.get("/")
    def frontend_missing():
        return JSONResponse(
            status_code=500,
            content={
                "error": "Frontend directory not found on server.",
                "frontend_dir_expected": FRONTEND_DIR,
                "hint": "Check that the frontend/ directory is deployed alongside backend/.",
            },
        )
