# Evidence Review — Case Desk

> **Attribution:** this project is a fork of the original *Evidence Review*
> repository by its original author (add the link to the upstream repo here).
> The original provides the claim-adjudication pipeline, the FastAPI backend
> and the case-file UI. Changes made in this fork are listed under
> [What this fork adds](#what-this-fork-adds). Check the upstream repo for its
> license terms before redistributing.

## What this fork adds

- **Confidence scoring**: the model returns a calibrated `confidence` (0–1),
  validated server-side and shown as a meter next to the verdict.
- **Human review queue**: verdicts below a confidence threshold
  (`MANUAL_REVIEW_THRESHOLD`, default 0.6) or flagged `manual_review_required`
  are marked *pending*. A reviewer can approve, reject or request more info,
  with a note.
- **Persistent case history**: every submission is stored in SQLite
  (`backend/store.py`). New **Case History** tab with stats, filters by
  verdict and review state, and click-through to any past case.
- **New endpoints**: `GET /api/claims`, `GET /api/claims/{id}`,
  `POST /api/claims/{id}/review`, `GET /api/stats`.
- **Hardening**: upload validation (type, size, count, claim length), HTML
  escaping of user text in the UI, and removal of the `/api/debug` endpoint
  that exposed server file paths.

Note: SQLite lives on the server's disk. On Render's free tier that disk is
ephemeral, so history resets on redeploy. Set `EVIDENCE_DB` to a persistent
disk path (or swap `store.py` for Postgres) to keep it.

---

A small full-stack demo wrapping the hackathon claim-adjudication logic in a
real upload-and-review UI: pick an object type, describe the claim, drop in
photos, and get a structured verdict back (supported / contradicted / not
enough information), styled like a case file with a stamped verdict.

```
project/
  pipeline/        # shared logic (copied from the hackathon code/ dir)
    schema.py
    prompts.py
    io_utils.py
  backend/
    app.py          # FastAPI: claims, history, review and stats endpoints
    store.py        # SQLite persistence
    requirements.txt
  frontend/
    index.html
    styles.css
    app.js
```

## Run it

**Locally** — backend serves the frontend too now (no separate static server needed):
```bash
cd backend
pip install -r requirements.txt
export ANTHROPIC_API_KEY=sk-...
uvicorn app:app --reload --port 8000
# open http://localhost:8000  -- this serves the UI AND the API from one process
```

## Deploy it online (Render, free tier)

This repo includes `render.yaml`, so it's a one-click deploy:

1. Push this project to a GitHub repo.
2. Go to [render.com](https://render.com) → **New** → **Blueprint** → connect the repo.
   Render reads `render.yaml` automatically and creates one web service.
3. When prompted, set the `ANTHROPIC_API_KEY` env var (marked `sync: false` in
   `render.yaml` so it's never committed to git — you paste it in Render's
   dashboard).
4. Deploy. Render gives you a URL like `https://evidence-review.onrender.com`
   — that one URL serves both the UI and the API (same origin, so no CORS
   config needed).

**Free-tier note**: Render's free web services spin down after ~15 minutes of
inactivity and take ~30–60s to wake back up on the next request — fine for a
demo/portfolio link, not for something you need always-warm.

### Alternative platforms
- **Railway** / **Heroku-style PaaS**: use the included `Procfile` instead of
  `render.yaml` — same idea, one process serving both UI and API.
- **Fly.io**: works the same way; add a `fly launch` and point its start
  command at `uvicorn app:app --host 0.0.0.0 --port 8080` from `backend/`.
- Any of these need the same single env var: `ANTHROPIC_API_KEY`.

### If you ever split frontend and backend onto different hosts
Set `window.EVIDENCE_REVIEW_API` in `frontend/index.html` before `app.js`
loads (e.g. `<script>window.EVIDENCE_REVIEW_API = "https://your-api.onrender.com";</script>`),
and add that frontend's origin to `allow_origins` in `backend/app.py` (it's
currently `"*"` for convenience, which is fine for a demo but should be
locked down to your actual frontend origin for anything real).

## What's real vs. what's a demo shortcut

- **Real**: the verdict logic is the same `schema.py` / `prompts.py` used by
  the batch pipeline — same enum enforcement, same system prompt rules
  (images are primary evidence, conversation defines what to check, history
  only adds risk context).
- **Demo shortcut**: `evidence_requirements.csv` and `user_history.csv`
  lookups aren't wired into `backend/app.py` yet (no `requirement`/real
  history is passed) — for a portfolio piece, hook those up the same way
  `claim_processor.py` does, keyed off a user ID field you'd add to the form.
- **Demo shortcut**: claims are saved to local SQLite, but uploaded images
  are not stored. For a real version, keep images in object storage.
- **Demo shortcut**: no auth, no rate limiting, CORS wide open — fine for
  localhost, not fine for anything public.

## Natural next steps if you keep building this

1. Store uploaded images (S3/GCS) and show them in the case history.
2. Move the database to Postgres for durable history.
3. Add basic auth so claims are tied to a real user (this also lets you wire
   in `user_history.csv`-style risk context for real).
4. Evaluate the confidence scores against labelled claims to check calibration.
